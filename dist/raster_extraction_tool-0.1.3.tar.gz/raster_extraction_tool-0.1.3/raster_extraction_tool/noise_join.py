import geopandas as gpd
import pandas as pd
from shapely.geometry import Point
from tqdm import tqdm
import dask_geopandas as dgpd
from datetime import datetime

csv_path = r"E:\BAG\BAG_april2024\verblijfsoject_table_xy_28992.csv"
gpkg_path = r"E:\EXPANSE\Netherlands\Physico-chemical\Noise\RTN_AVG_XX_XX_19_v3.gpkg"
output_path = r"E:\BAG\BAG_april2024\verblijfsoject_table_xy_28992_noise.csv"



print('reading csv')
csv_df = pd.read_csv(csv_path,sep=';',decimal=',')
csv_df = csv_df[(csv_df['X'] != "NOT FOUND") & (csv_df['Y'] != "NOT FOUND")]
geometry = [Point(xy) for xy in zip(csv_df['X'], csv_df['Y'])]
csv_gdf = gpd.GeoDataFrame(csv_df, geometry=geometry, crs="EPSG:28992")

print('reading noise)')
x = datetime.now()
gpkg_gdf = dgpd.read_file(gpkg_path,npartitions=8)
gpkg_gdf = gpkg_gdf.compute()
print(datetime.now()-x)



print('reprojecting')
csv_gdf = csv_gdf.to_crs(epsg=3035)
gpkg_gdf = gpkg_gdf.to_crs(epsg=3035)


print('joining')
tqdm.pandas(desc="Processing spatial join")
joined_gdf = gpd.sjoin_nearest(
    csv_gdf.progress_apply(lambda x: x, axis=1), 
    gpkg_gdf, 
    how="left", 
    distance_col="distance",
)

print(joined_gdf)
joined_gdf.drop(columns=["geometry","index_right",'lau_id','st_x','st_y']).to_csv(output_path, sep=';',index=False)

print(f"Joined data saved to {output_path}")