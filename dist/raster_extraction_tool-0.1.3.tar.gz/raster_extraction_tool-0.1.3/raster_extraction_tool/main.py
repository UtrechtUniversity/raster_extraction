import raster_extraction_tool.raster_extraction_functions as ref

if __name__ == "__main__":
    ref.extract_values(
        input_csv=r"O:\DGK\IRAS\EEPI\Privacy\GIS\panel_blq\Panel_blq_finishers_postcode_house_nr_geocoded.csv",
        raster_folder=r"E:\EXPANSE\update2020+\exposure_yoda\Netherlands\Physico-chemical\AirPollution",
        output_csv=r"O:\DGK\IRAS\EEPI\Privacy\GIS\panel_blq\2025_koppeling\Panel_blq_finishers_postcode_house_nr_geocoded_exposures.csv",
        in_crs='EPSG:28992',
        raster_crs='EPSG:3035',
        decimal='.',
        sep = ';' ,
        writemethod='concat',
    )
